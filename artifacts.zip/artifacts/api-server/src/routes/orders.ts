import { Router } from "express";
import { db, ordersTable } from "@workspace/db";
import { desc, sql, eq } from "drizzle-orm";

const router = Router();

const PRICES: Record<string, number> = {
  "golden-glow": 95,
  "deep-cleansing": 95,
  "bridal-glow": 95,
  combo: 180,
  "combo-bridal-rose": 180,
  "combo-chicksa-rose": 180,
  "combo-chicksa-bridal": 180,
  "combo-rose-rose": 180,
};

router.get("/orders", async (req, res) => {
  try {
    const orders = await db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt));
    res.json(orders.map((o) => ({ ...o, createdAt: o.createdAt.toISOString() })));
  } catch (err) {
    req.log.error({ err }, "Failed to list orders");
    res.status(500).json({ error: "Failed to fetch orders" });
  }
});

router.post("/orders", async (req, res) => {
  const { customerName, email, phone, deliveryAddress, productSlug, quantity } = req.body;

  if (!customerName || !phone || !deliveryAddress || !productSlug || !quantity) {
    res.status(400).json({ error: "Missing required fields" });
    return;
  }

  const pricePerUnit = PRICES[productSlug];
  if (!pricePerUnit) {
    res.status(400).json({ error: "Invalid product" });
    return;
  }

  const qty = Number(quantity);
  if (isNaN(qty) || qty < 1 || qty > 10) {
    res.status(400).json({ error: "Quantity must be between 1 and 10" });
    return;
  }

  try {
    const [order] = await db
      .insert(ordersTable)
      .values({
        customerName,
        email: email || null,
        phone,
        deliveryAddress,
        productSlug,
        quantity: qty,
        totalInr: pricePerUnit * qty,
        status: "pending",
      })
      .returning();

    res.status(201).json({ ...order, createdAt: order.createdAt.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to create order");
    res.status(500).json({ error: "Failed to place order" });
  }
});

router.get("/orders/summary", async (req, res) => {
  try {
    const [summary] = await db
      .select({
        totalOrders: sql<number>`count(*)::int`,
        totalRevenue: sql<number>`coalesce(sum(total_inr), 0)::int`,
        goldenGlowOrders: sql<number>`count(*) filter (where product_slug = 'golden-glow')::int`,
        deepCleansingOrders: sql<number>`count(*) filter (where product_slug = 'deep-cleansing')::int`,
        comboOrders: sql<number>`count(*) filter (where product_slug = 'combo')::int`,
      })
      .from(ordersTable);

    res.json(summary);
  } catch (err) {
    req.log.error({ err }, "Failed to get orders summary");
    res.status(500).json({ error: "Failed to fetch summary" });
  }
});

export default router;
