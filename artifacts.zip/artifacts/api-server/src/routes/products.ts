import { Router } from "express";

const router = Router();

const PRODUCTS = [
  {
    id: 1,
    name: "Chicksa Soap",
    tagline: "Deeply Nourish with Ancient Ubtan",
    ingredients: "Natural Chicksa (Ubtan), Saffron & Amme Haldi (Turmeric)",
    bestFor: "Deep nourishment, skin brightening and traditional herbal care",
    priceInr: 95,
    slug: "golden-glow",
  },
  {
    id: 2,
    name: "Rose Soap",
    tagline: "Bloom with Radiance",
    ingredients: "Saffron & Rose Water",
    bestFor: "Glowing skin, pinkish effect and deep hydration",
    priceInr: 95,
    slug: "deep-cleansing",
  },
  {
    id: 4,
    name: "Sitara Bridal Soap",
    tagline: "Glow Like a Bride",
    ingredients: "Rose Water, Saffron, Raw Milk & Sandalwood",
    bestFor: "Bridal glow, deep nourishment and radiant skin for your special day",
    priceInr: 95,
    slug: "bridal-glow",
  },
  {
    id: 3,
    name: "The Combo Pack",
    tagline: "Best of Both Worlds",
    ingredients: "Both Chicksa Soap & Rose Soap",
    bestFor: "Complete skincare — nourish, brighten, and hydrate",
    priceInr: 180,
    slug: "combo",
  },
  {
    id: 5,
    name: "Bridal + Rose Combo",
    tagline: "Glow & Bloom Together",
    ingredients: "Sitara Bridal Soap & Rose Soap",
    bestFor: "Bridal radiance with rose petal softness",
    priceInr: 180,
    slug: "combo-bridal-rose",
  },
  {
    id: 6,
    name: "Chicksa + Rose Combo",
    tagline: "Nourish & Glow",
    ingredients: "Chicksa Soap & Rose Soap",
    bestFor: "Deep nourishment and glowing radiance",
    priceInr: 180,
    slug: "combo-chicksa-rose",
  },
  {
    id: 7,
    name: "Chicksa + Bridal Combo",
    tagline: "Ancient & Radiant",
    ingredients: "Chicksa Soap & Sitara Bridal Soap",
    bestFor: "Ubtan nourishment with bridal-level glow",
    priceInr: 180,
    slug: "combo-chicksa-bridal",
  },
  {
    id: 8,
    name: "Double Rose Combo",
    tagline: "Twice the Bloom",
    ingredients: "Two Rose Soaps",
    bestFor: "Maximum rose water radiance for glowing skin",
    priceInr: 180,
    slug: "combo-rose-rose",
  },
];

router.get("/products", (_req, res) => {
  res.json(PRODUCTS);
});

export default router;
