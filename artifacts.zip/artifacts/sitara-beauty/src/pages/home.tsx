import { useState, useEffect } from 'react';
import { useListProducts, useCreateOrder } from '@workspace/api-client-react';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { motion, AnimatePresence } from 'framer-motion';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

import { 
  Menu, X, ShoppingBag, Leaf, Package, Heart, Truck, Instagram, Facebook, MessageCircle, Star, Phone,
  Minus, Plus, Trash2, ShoppingCart
} from 'lucide-react';

type CartItem = { slug: string; name: string; price: number; qty: number; };

import rosePhoto from '@assets/1785814130486_1785814241102.png';
import roseComboPhoto from '@assets/1785814802120_1785814947224.png';
import heroPhoto from '@assets/Screenshot_20260715_000517_Gallery_1784055658889.jpg';
import chicksaPhoto from '@assets/IMG-20260502-WA0014(2)_1783910294606.jpg';
import bridalPhoto from '@assets/1784411744602_1785523568102.png';

const orderSchema = z.object({
  customerName: z.string().min(2, "Please enter your full name"),
  email: z.string().email("Please enter a valid email").optional().or(z.literal("")),
  phone: z.string().min(10, "Phone number must be at least 10 digits"),
  deliveryAddress: z.string().min(10, "Please provide a complete delivery address"),
  productSlug: z.string().min(1, "Please select a product"),
  quantity: z.coerce.number().min(1).max(10)
});

type OrderFormValues = z.infer<typeof orderSchema>;

const faqs = [
  { q: "How long does shipping take?", a: "3–7 business days across India" },
  { q: "Do you offer delivery across India?", a: "Yes, we deliver pan India. Delivery takes 3–7 business days." },
  { q: "What are the ingredients?", a: "Saffron, Rose Water, Chicksa Ubtan, Amme Haldi, Honey. All natural, no parabens." },
  { q: "Is this suitable for sensitive skin?", a: "Yes, all our soaps are gentle and chemical-free" },
  { q: "How do I use the soap?", a: "Use daily on wet skin, lather well, rinse. Best results in 2–4 weeks." },
  { q: "Can I return if I'm not satisfied?", a: "Yes, easy returns within 7 days of delivery" }
];

const ingredientsData = [
  { name: "Saffron", desc: "Brightens and evens skin tone" },
  { name: "Rose Water", desc: "Deep hydration, pinkish glow" },
  { name: "Chicksa Ubtan", desc: "Ancient exfoliant, removes tanning" },
  { name: "Amme Haldi", desc: "Anti-inflammatory, fades blemishes" },
  { name: "Honey", desc: "Moisturising, antibacterial" },
  { name: "Handcrafted", desc: "No machines, no shortcuts" }
];

export default function Home() {
  const { toast } = useToast();
  
  const { data: products, isLoading: isLoadingProducts } = useListProducts();
  const createOrder = useCreateOrder();
  
  const [orderSuccess, setOrderSuccess] = useState<{name: string, product: string} | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [cartBump, setCartBump] = useState(false);

  // --- Cart calculations (matching Python snippet logic) ---
  const SHIPPING_THRESHOLD = 399;
  const SHIPPING_FEE = 50;
  const cartSubtotal = cartItems.reduce((sum, item) => sum + item.price * item.qty, 0);
  const cartShipping = cartSubtotal >= SHIPPING_THRESHOLD ? 0 : cartItems.length > 0 ? SHIPPING_FEE : 0;
  const cartTotal = cartSubtotal + cartShipping;
  const cartCount = cartItems.reduce((sum, item) => sum + item.qty, 0);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    handleScroll(); // set correct state immediately on mount — prevents flicker
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const form = useForm<OrderFormValues>({
    resolver: zodResolver(orderSchema),
    defaultValues: {
      customerName: "",
      email: "",
      phone: "",
      deliveryAddress: "",
      productSlug: "",
      quantity: 1
    }
  });

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  const handleAddToCart = (slug: string, name: string, price: number) => {
    setCartItems(prev => {
      const existing = prev.find(i => i.slug === slug);
      if (existing) return prev.map(i => i.slug === slug ? { ...i, qty: i.qty + 1 } : i);
      return [...prev, { slug, name, price, qty: 1 }];
    });
    setCartBump(true);
    setTimeout(() => setCartBump(false), 400);
    // Show a brief toast — do NOT open cart drawer (user taps cart icon to open)
    toast({ title: `✓ Added to cart`, description: `${name} — tap the cart icon to review` });
  };

  const handleQtyChange = (slug: string, delta: number) => {
    setCartItems(prev =>
      prev.map(i => i.slug === slug ? { ...i, qty: Math.max(1, i.qty + delta) } : i)
    );
  };

  const handleRemoveItem = (slug: string) => {
    setCartItems(prev => prev.filter(i => i.slug !== slug));
  };

  const buildWhatsAppCartMessage = () => {
    const lines = cartItems.map(i => `• ${i.name} x${i.qty} = ₹${i.price * i.qty}`).join('%0A');
    const msg = `Hi! I visited your website and want to order:%0A${lines}%0ASubtotal: ₹${cartSubtotal}%0AShipping: ₹${cartShipping}%0ATotal: ₹${cartTotal} ✨`;
    return `https://wa.me/919620965688?text=${msg}`;
  };

  const onSubmit = (data: OrderFormValues) => {
    createOrder.mutate(
      { data },
      {
        onSuccess: (order) => {
          const selectedProduct = products?.find(p => p.slug === order.productSlug);
          setOrderSuccess({
            name: order.customerName,
            product: selectedProduct?.name || 'your items'
          });
          form.reset();
          setCartItems([]);
        },
        onError: () => {
          toast({
            title: "Something went wrong",
            description: "We couldn't place your order. Please try again.",
            variant: "destructive"
          });
        }
      }
    );
  };

  const staggerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.15 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    show: { opacity: 1, y: 0, transition: { duration: 0.8, ease: "easeOut" } }
  };

  return (
    <div className="min-h-[100dvh] w-full flex flex-col relative bg-background text-foreground font-sans">

      {/* Sticky Navbar */}
      <nav className={`sticky top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-background shadow-sm py-4' : 'bg-[#0D0603] py-6'}`}>
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <div className="flex flex-col items-start cursor-pointer" onClick={() => window.scrollTo(0,0)}>
            <span className={`font-serif font-bold italic text-3xl tracking-wide leading-none transition-colors duration-300 ${isScrolled ? 'text-foreground' : 'text-white'}`}>SITARA</span>
            <span className={`text-[0.6rem] font-medium tracking-widest uppercase mt-1 transition-colors duration-300 ${isScrolled ? 'text-foreground/80' : 'text-white/60'}`}>Natural Soap</span>
          </div>
          
          <div className="hidden md:flex items-center gap-10">
            <button onClick={() => scrollToSection('products')} className={`text-sm uppercase tracking-wider font-medium transition-colors ${isScrolled ? 'text-foreground/80 hover:text-primary' : 'text-white/80 hover:text-white'}`}>Shop</button>
            <button onClick={() => scrollToSection('ingredients')} className={`text-sm uppercase tracking-wider font-medium transition-colors ${isScrolled ? 'text-foreground/80 hover:text-primary' : 'text-white/80 hover:text-white'}`}>Ingredients</button>
            <button onClick={() => scrollToSection('story')} className={`text-sm uppercase tracking-wider font-medium transition-colors ${isScrolled ? 'text-foreground/80 hover:text-primary' : 'text-white/80 hover:text-white'}`}>Our Story</button>
            <button onClick={() => scrollToSection('faq')} className={`text-sm uppercase tracking-wider font-medium transition-colors ${isScrolled ? 'text-foreground/80 hover:text-primary' : 'text-white/80 hover:text-white'}`}>FAQ</button>
          </div>

          <div className="flex items-center gap-4">
            <button 
              className="relative p-2 text-foreground hover:text-primary transition-colors"
              onClick={() => setCartOpen(true)}
              data-testid="button-cart"
            >
              <motion.div animate={cartBump ? { scale: [1, 1.3, 1] } : {}}>
                <ShoppingBag className="w-6 h-6" />
              </motion.div>
              <AnimatePresence>
                {cartCount > 0 && (
                  <motion.div 
                    initial={{ scale: 0 }} 
                    animate={{ scale: 1 }} 
                    exit={{ scale: 0 }}
                    className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-[0.65rem] font-bold w-5 h-5 flex items-center justify-center rounded-full"
                  >
                    {cartCount}
                  </motion.div>
                )}
              </AnimatePresence>
            </button>

            <button 
              className="md:hidden text-foreground p-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-background pt-32 px-8 flex flex-col gap-8 md:hidden h-[100dvh]"
          >
            <button onClick={() => scrollToSection('products')} className="text-3xl font-serif text-left border-b border-border pb-4 text-foreground hover:text-primary">Shop</button>
            <button onClick={() => scrollToSection('ingredients')} className="text-3xl font-serif text-left border-b border-border pb-4 text-foreground hover:text-primary">Ingredients</button>
            <button onClick={() => scrollToSection('story')} className="text-3xl font-serif text-left border-b border-border pb-4 text-foreground hover:text-primary">Our Story</button>
            <button onClick={() => scrollToSection('faq')} className="text-3xl font-serif text-left border-b border-border pb-4 text-foreground hover:text-primary">FAQ</button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section id="shop" className="relative -mt-[100px] overflow-hidden">

        {/* ── MOBILE HERO ── */}
        <div className="md:hidden bg-[#0D0603]">
          {/* Content — auto-height, no fixed percentage */}
          <div className="px-6 pb-7" style={{ paddingTop: '110px' }}>
            <motion.div initial="hidden" animate="show" variants={staggerVariants}>

              {/* Social proof pill */}
              <motion.div variants={itemVariants} className="flex items-center gap-2 mb-5">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-[#C4714A] text-[#C4714A]" />
                  ))}
                </div>
                <span className="text-xs text-[#F7F3EE]/70 font-light">160+ happy customers · Bangalore</span>
              </motion.div>

              {/* Badge */}
              <motion.div variants={itemVariants} className="mb-4 inline-block bg-secondary px-4 py-1.5 rounded-sm">
                <span className="text-[0.65rem] uppercase tracking-[0.2em] font-bold text-secondary-foreground">Handcrafted &middot; All Natural</span>
              </motion.div>

              {/* Heading */}
              <motion.h1 variants={itemVariants} className="text-[2.8rem] font-serif text-white leading-[1.05] mb-3">
                Glow Like<br />Nature Intended.
              </motion.h1>

              {/* Subtext */}
              <motion.p variants={itemVariants} className="text-[0.92rem] text-[#F7F3EE]/75 mb-6 leading-relaxed font-light">
                Remove tanning. Brighten skin. Nourish deeply.<br />Ancient Indian recipes, zero chemicals.
              </motion.p>

              {/* Benefit chips */}
              <motion.div variants={itemVariants} className="flex gap-2 mb-6 flex-wrap">
                {[
                  { icon: Leaf, label: 'No Chemicals' },
                  { icon: Heart, label: 'Cruelty Free' },
                  { icon: Package, label: 'Handmade' },
                ].map(({ icon: Icon, label }) => (
                  <span key={label} className="flex items-center gap-1.5 text-[0.7rem] text-[#F7F3EE]/80 bg-white/8 border border-white/10 rounded-full px-3 py-1.5 font-medium">
                    <Icon className="w-3 h-3 text-[#C4714A]" /> {label}
                  </span>
                ))}
              </motion.div>

              {/* CTA */}
              <motion.div variants={itemVariants} className="flex items-center gap-4">
                <Button
                  className="rounded-full bg-primary hover:bg-primary/90 text-primary-foreground px-7 py-5 text-sm font-semibold shadow-xl"
                  onClick={() => scrollToSection('products')}
                  data-testid="button-hero-shop"
                >
                  Shop Now &darr;
                </Button>
                <span className="text-[0.72rem] text-[#F7F3EE]/45 font-light leading-tight">Free delivery<br />above ₹399</span>
              </motion.div>
            </motion.div>
          </div>

          {/* Product image — fixed height, directly below content, no gap */}
          <div className="relative h-[260px] overflow-hidden">
            <img
              src={heroPhoto}
              className="w-full h-full object-cover object-[center_62%]"
              alt="Sitara Natural Soap"
            />
            {/* Blend top edge into dark bg */}
            <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, #0D0603 0%, transparent 20%, transparent 70%, #0D0603 100%)' }} />
          </div>
        </div>

        {/* ── DESKTOP HERO ── */}
        <div className="hidden md:flex items-center min-h-[90vh] relative">
          <div className="absolute inset-0 z-0">
            <img src={heroPhoto} className="w-full h-full object-cover object-center" alt="Hero Background" />
            <div className="absolute inset-0 bg-[#1E0F05] opacity-45" />
          </div>
          <div className="container max-w-7xl mx-auto px-6 relative z-10">
            <motion.div initial="hidden" animate="show" variants={staggerVariants} className="max-w-2xl text-left">
              <motion.div variants={itemVariants} className="mb-6 inline-block bg-secondary px-4 py-1.5 rounded-sm">
                <span className="text-[0.65rem] uppercase tracking-[0.2em] font-bold text-secondary-foreground">Handcrafted &middot; All Natural</span>
              </motion.div>
              <motion.h1 variants={itemVariants} className="text-8xl font-serif text-white leading-[1.1] mb-6">
                Glow Like <br /> Nature Intended.
              </motion.h1>
              <motion.p variants={itemVariants} className="text-xl text-[#F7F3EE] mb-10 leading-relaxed font-light max-w-lg">
                Remove tanning. Brighten skin. Nourish deeply. Ancient Indian recipes, zero chemicals.
              </motion.p>
              <motion.div variants={itemVariants} className="flex flex-col items-start gap-4">
                <Button
                  className="rounded-full bg-primary hover:bg-primary/90 text-primary-foreground px-10 py-7 text-lg font-medium shadow-xl transition-transform hover:scale-105"
                  onClick={() => scrollToSection('products')}
                  data-testid="button-hero-shop"
                >
                  Shop the Collection &darr;
                </Button>
                <span className="text-sm text-[#F7F3EE]/80 font-light ml-2">Free delivery above ₹399 &middot; Easy returns</span>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Value Props Strip */}
      <section className="bg-card border-b border-border py-10">
        <div className="container max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { icon: Leaf, label: "100% Natural" },
            { icon: Package, label: "Free Returns" },
            { icon: Heart, label: "Ethically Made" },
            { icon: Truck, label: "Free Delivery ₹399+" }
          ].map((prop, idx) => (
            <div key={idx} className="flex flex-col items-center text-center gap-4 group">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <prop.icon className="w-6 h-6 text-secondary" />
              </div>
              <span className="text-sm font-medium tracking-wide text-foreground">{prop.label}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Products Grid */}
      <section id="products" className="py-24 md:py-32 relative z-10 bg-background">
        <div className="container max-w-7xl mx-auto px-6">
          <div className="text-center mb-16 lg:mb-24">
            <span className="text-sm uppercase tracking-widest font-bold text-secondary mb-4 block">Our Collection</span>
            <h2 className="text-5xl lg:text-6xl font-serif text-foreground">Crafted for Your Skin</h2>
          </div>

          {isLoadingProducts ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-12">
              <Skeleton className="h-[400px] w-full rounded-xl" />
              <Skeleton className="h-[400px] w-full rounded-xl" />
              <Skeleton className="h-[400px] w-full rounded-xl" />
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 lg:gap-12">
              {products?.map((product, idx) => {
                // Photo pair lookup for combos — [left, right]
                const comboPairs: Record<string, [string, string]> = {
                  'combo':               [roseComboPhoto,   chicksaPhoto],
                  'combo-bridal-rose':   [bridalPhoto, roseComboPhoto],
                  'combo-chicksa-rose':  [chicksaPhoto, roseComboPhoto],
                  'combo-chicksa-bridal':[chicksaPhoto, bridalPhoto],
                  'combo-rose-rose':     [roseComboPhoto, roseComboPhoto],
                };
                const comboPair = comboPairs[product.slug];
                const isCombo = !!comboPair;

                let photo = rosePhoto;
                if (product.slug === 'golden-glow') photo = chicksaPhoto;
                if (product.slug === 'bridal-glow') photo = bridalPhoto;
                
                return (
                  <motion.div 
                    key={product.id}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-50px" }}
                    transition={{ duration: 0.6, delay: (idx % 4) * 0.1 }}
                    className="flex flex-col group cursor-pointer"
                    onClick={() => handleAddToCart(product.slug, product.name, product.priceInr)}
                    data-testid={`card-product-${product.slug}`}
                  >
                    <div className="relative aspect-square overflow-hidden rounded-xl mb-6 bg-card border border-border shadow-sm group-hover:shadow-md transition-shadow">
                      {isCombo ? (
                        <div className="absolute inset-0 flex">
                          <img src={comboPair[0]} className="w-1/2 h-full object-cover transform group-hover:scale-105 transition-transform duration-500" alt="soap 1" />
                          <img src={comboPair[1]} className="w-1/2 h-full object-cover transform group-hover:scale-105 transition-transform duration-500" alt="soap 2" />
                        </div>
                      ) : (
                        <img 
                          src={photo} 
                          alt={product.name}
                          className="w-full h-full object-cover transform group-hover:scale-105 transition-transform duration-700 ease-out"
                        />
                      )}
                      
                      <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-opacity duration-300 flex flex-col items-center justify-center gap-3">
                        <Button 
                          className="rounded-full bg-primary text-primary-foreground hover:bg-primary/90 px-8 py-5 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 shadow-xl"
                          onClick={(e) => { e.stopPropagation(); handleAddToCart(product.slug, product.name, product.priceInr); }}
                          data-testid={`button-add-${product.slug}`}
                        >
                          + Add to Cart
                        </Button>
                        <a
                          href={`https://wa.me/919620965688?text=Hi!%20I%20visited%20your%20website%20and%20I%20want%20to%20order%20${encodeURIComponent(product.name)}%20%E2%9C%A8`}
                          target="_blank"
                          rel="noopener noreferrer"
                          data-testid={`button-whatsapp-${product.slug}`}
                          onClick={(e) => e.stopPropagation()}
                          className="flex items-center gap-2 rounded-full bg-[#25D366] text-white px-6 py-3 font-medium text-sm transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 shadow-xl hover:bg-[#1ebe5d]"
                        >
                          <MessageCircle className="w-4 h-4" /> Order via WhatsApp
                        </a>
                      </div>
                    </div>
                    
                    <div className="flex flex-col flex-grow text-center items-center">
                      <div className="flex gap-1 mb-2">
                        {[...Array(5)].map((_, i) => <Star key={i} className="w-3.5 h-3.5 fill-primary text-primary" />)}
                      </div>
                      <h3 className="text-2xl font-serif text-foreground mb-2">{product.name}</h3>
                      <p className="text-sm text-muted-foreground font-light mb-3 line-clamp-2">{product.ingredients}</p>
                      {product.slug === 'golden-glow' && (
                        <p className="text-xs font-medium text-amber-700 bg-amber-50 border border-amber-200 rounded-full px-3 py-1 mb-3">
                          For body use only · Not for face
                        </p>
                      )}
                      <div className="mt-auto">
                        <span className="text-xl font-bold font-sans text-primary">₹{product.priceInr}</span>
                        <p className="text-xs text-muted-foreground mt-1">+ delivery fees</p>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {/* Brand Story Split Screen */}
      <section id="story" className="relative z-10 bg-secondary overflow-hidden">
        <div className="grid lg:grid-cols-2 min-h-[80vh]">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative h-[50vh] lg:h-auto"
          >
            <img src={chicksaPhoto} className="absolute inset-0 w-full h-full object-cover" alt="Our Story" />
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="flex flex-col justify-center p-12 lg:p-24 bg-secondary text-secondary-foreground relative"
          >
            <span className="text-xs uppercase tracking-widest font-bold text-secondary-foreground/60 mb-6 block">Our Story</span>
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif leading-tight mb-8">
              Rooted in Tradition, <br /> Made for Today
            </h2>
            <div className="w-24 h-px bg-primary mb-8" />
            <p className="text-lg font-light leading-relaxed mb-10 text-secondary-foreground/80 max-w-lg">
              Sitara began in a small kitchen with a single recipe passed down through generations. Every bar we make carries the wisdom of Ayurvedic skincare — handcrafted with saffron, rose water, and ancient ubtan. No chemicals. No shortcuts. Just your skin, the way it was meant to be.
            </p>
            <button 
              className="group flex items-center gap-2 text-primary font-bold text-sm uppercase tracking-wider hover:text-primary/80 transition-colors"
              onClick={() => scrollToSection('ingredients')}
            >
              Meet Our Ingredients 
              <span className="transform group-hover:translate-x-1 transition-transform">&rarr;</span>
            </button>
          </motion.div>
        </div>
      </section>

      {/* Ingredients Grid */}
      <section id="ingredients" className="py-24 md:py-32 relative z-10 bg-background">
        <div className="container max-w-7xl mx-auto px-6">
          <div className="text-center mb-16 lg:mb-24">
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif text-foreground">What Goes Into Every Bar</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {ingredientsData.map((ing, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ delay: idx * 0.1, duration: 0.5 }}
                className="bg-card p-8 border-l-4 border-l-primary border border-border shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start gap-4">
                  <div className="mt-1 w-2 h-2 rounded-full bg-primary" />
                  <div>
                    <h4 className="text-2xl font-serif italic text-foreground mb-2">{ing.name}</h4>
                    <p className="text-sm text-muted-foreground font-light">{ing.desc}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Order Form Section */}
      <section id="order" className="py-24 md:py-32 relative z-10 bg-card border-y border-border">
        <div className="container max-w-3xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-serif text-foreground mb-4">Ready to Glow?</h2>
            <p className="text-muted-foreground font-light">Fill out the form below to place your order directly.</p>
          </div>

          <div className="bg-background p-8 md:p-12 rounded-xl shadow-xl border border-border">
            {orderSuccess ? (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center py-12"
              >
                <div className="w-20 h-20 bg-secondary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Heart className="w-10 h-10 text-secondary" />
                </div>
                <h3 className="text-3xl font-serif text-foreground mb-4">Thank You, {orderSuccess.name}!</h3>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                  Your order for <span className="font-semibold text-foreground">{orderSuccess.product}</span> has been placed successfully. You can also reach us directly on WhatsApp to confirm your order.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 justify-center mb-4">
                  <a
                    href="https://wa.me/919620965688?text=Hi!%20I%20visited%20your%20website%20and%20I%20want%20to%20order%20Sitara%20Soap%20%E2%9C%A8"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 rounded-full bg-[#25D366] text-white px-8 py-3 font-semibold hover:bg-[#1ebe5d] transition-colors shadow"
                  >
                    <MessageCircle className="w-5 h-5" /> Chat on WhatsApp
                  </a>
                  <Button 
                    className="rounded-full bg-primary text-primary-foreground hover:bg-primary/90 px-8 py-6"
                    onClick={() => setOrderSuccess(null)}
                  >
                    Place Another Order
                  </Button>
                </div>
              </motion.div>
            ) : (
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="customerName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-foreground">Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your name" className="bg-card border-border h-12" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-foreground">Phone Number</FormLabel>
                          <FormControl>
                            <Input placeholder="10-digit mobile number" className="bg-card border-border h-12" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-foreground">Email Address (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="For order updates" className="bg-card border-border h-12" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="deliveryAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-foreground">Complete Delivery Address</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="House/Flat No, Street, Landmark, City, Pincode" 
                            className="bg-card border-border min-h-[100px] resize-y" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid md:grid-cols-3 gap-6 pt-2">
                    <div className="md:col-span-2">
                      <FormField
                        control={form.control}
                        name="productSlug"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-foreground">Select Product</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value || undefined}>
                              <FormControl>
                                <SelectTrigger className="bg-card border-border h-12">
                                  <SelectValue placeholder="Choose a soap..." />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {isLoadingProducts ? (
                                  <SelectItem value="loading" disabled>Loading products...</SelectItem>
                                ) : (
                                  products?.map((p) => (
                                    <SelectItem key={p.id} value={p.slug}>
                                      {p.name} — ₹{p.priceInr}
                                    </SelectItem>
                                  ))
                                )}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="quantity"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-foreground">Quantity</FormLabel>
                          <FormControl>
                            <Input type="number" min="1" max="10" className="bg-card border-border h-12" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="pt-6">
                    <Button 
                      type="submit" 
                      className="w-full h-14 text-lg font-serif rounded-full bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg"
                      disabled={createOrder.isPending}
                      data-testid="button-submit-order"
                    >
                      {createOrder.isPending ? "Processing..." : "Place Your Order"}
                    </Button>
                  </div>
                </form>
              </Form>
            )}
          </div>
        </div>
      </section>

      {/* FAQ Accordion */}
      <section id="faq" className="py-24 md:py-32 relative z-10 bg-background">
        <div className="container max-w-4xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif text-foreground">Frequently Asked Questions</h2>
          </div>

          <Accordion type="single" collapsible className="w-full space-y-4">
            {faqs.map((faq, idx) => (
              <AccordionItem key={idx} value={`item-${idx}`} className="bg-card border border-border rounded-lg px-6 data-[state=open]:border-primary transition-colors">
                <AccordionTrigger className="text-left font-serif text-xl hover:no-underline py-6">
                  <span className="flex gap-4 items-center">
                    <span className="text-primary font-sans text-sm font-bold">0{idx + 1}</span>
                    {faq.q}
                  </span>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground font-light text-base pb-6 pl-9">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card py-16 border-t border-border">
        <div className="container max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
            <div className="md:col-span-1">
              <span className="font-serif font-bold italic text-3xl tracking-wide leading-none text-foreground block mb-4">SITARA</span>
              <p className="text-sm text-muted-foreground font-light mb-6">
                Handcrafted natural skincare rooted in ancient Indian traditions.
              </p>
              <div className="flex gap-4">
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors"><Instagram className="w-5 h-5" /></a>
                <a href="#" className="text-muted-foreground hover:text-primary transition-colors"><Facebook className="w-5 h-5" /></a>
                <a href="https://wa.me/919620965688?text=Hi!%20I%20visited%20your%20website%20and%20I%20want%20to%20order%20Sitara%20Soap%20%E2%9C%A8" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-[#25D366] transition-colors"><MessageCircle className="w-5 h-5" /></a>
              </div>
            </div>
            
            <div>
              <h4 className="font-bold uppercase tracking-wider text-xs mb-6 text-foreground">Shop</h4>
              <ul className="space-y-4 text-sm font-light text-muted-foreground">
                <li><button onClick={() => scrollToSection('products')} className="hover:text-primary transition-colors">All Products</button></li>
                <li><button onClick={() => handleAddToCart('combo')} className="hover:text-primary transition-colors">Combo Offers</button></li>
                <li><button onClick={() => scrollToSection('order')} className="hover:text-primary transition-colors">Order Now</button></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold uppercase tracking-wider text-xs mb-6 text-foreground">Explore</h4>
              <ul className="space-y-4 text-sm font-light text-muted-foreground">
                <li><button onClick={() => scrollToSection('story')} className="hover:text-primary transition-colors">Our Story</button></li>
                <li><button onClick={() => scrollToSection('ingredients')} className="hover:text-primary transition-colors">Ingredients</button></li>
                <li><button onClick={() => scrollToSection('faq')} className="hover:text-primary transition-colors">FAQ</button></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold uppercase tracking-wider text-xs mb-6 text-foreground">Contact</h4>
              <ul className="space-y-4 text-sm font-light text-muted-foreground">
                <li className="flex items-center gap-2"><Instagram className="w-4 h-4" /> @Sitara_soap</li>
                <li>Handcrafted with love in Bangalore, India</li>
              </ul>
            </div>
          </div>
          
          <div className="pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center gap-4 text-xs font-light text-muted-foreground">
            <p>&copy; {new Date().getFullYear()} Sitara Natural Soap &middot; Handcrafted in India</p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-primary">Privacy Policy</a>
              <a href="#" className="hover:text-primary">Terms of Service</a>
              <a href="#" className="hover:text-primary">Refund Policy</a>
            </div>
          </div>
        </div>
      </footer>

      {/* Cart Drawer */}
      <AnimatePresence>
        {cartOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/40 z-50 backdrop-blur-sm"
              onClick={() => setCartOpen(false)}
            />
            {/* Drawer */}
            <motion.div
              initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 28, stiffness: 280 }}
              className="fixed right-0 top-0 h-full w-full max-w-md bg-background z-50 shadow-2xl flex flex-col"
            >
              {/* Header */}
              <div className="flex items-center justify-between px-6 py-5 border-b border-border">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5 text-primary" />
                  <h2 className="font-serif text-xl text-foreground">Your Cart</h2>
                  {cartCount > 0 && (
                    <span className="bg-primary text-primary-foreground text-xs font-bold px-2 py-0.5 rounded-full">{cartCount}</span>
                  )}
                </div>
                <button onClick={() => setCartOpen(false)} className="p-2 hover:bg-card rounded-full transition-colors">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Items */}
              <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
                {cartItems.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
                    <ShoppingCart className="w-16 h-16 text-muted-foreground/30" />
                    <p className="text-muted-foreground font-light">Your cart is empty</p>
                    <Button className="rounded-full bg-primary text-primary-foreground" onClick={() => { setCartOpen(false); scrollToSection('products'); }}>
                      Browse Products
                    </Button>
                  </div>
                ) : (
                  cartItems.map(item => (
                    <motion.div
                      key={item.slug}
                      layout
                      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: 40 }}
                      className="flex items-center gap-4 bg-card rounded-xl p-4 border border-border"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="font-serif text-foreground text-lg leading-tight">{item.name}</p>
                        <p className="text-sm text-muted-foreground">₹{item.price} each</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <button onClick={() => handleQtyChange(item.slug, -1)} className="w-7 h-7 rounded-full border border-border flex items-center justify-center hover:bg-primary hover:text-primary-foreground hover:border-primary transition-colors">
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-6 text-center font-semibold text-foreground">{item.qty}</span>
                        <button onClick={() => handleQtyChange(item.slug, +1)} className="w-7 h-7 rounded-full border border-border flex items-center justify-center hover:bg-primary hover:text-primary-foreground hover:border-primary transition-colors">
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                      <div className="text-right min-w-[56px]">
                        <p className="font-bold text-primary">₹{item.price * item.qty}</p>
                      </div>
                      <button onClick={() => handleRemoveItem(item.slug)} className="p-1.5 hover:bg-destructive/10 hover:text-destructive rounded-full transition-colors text-muted-foreground">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </motion.div>
                  ))
                )}
              </div>

              {/* Order Summary + CTA */}
              {cartItems.length > 0 && (
                <div className="border-t border-border px-6 py-5 space-y-3 bg-card">
                  {/* Line items */}
                  <div className="space-y-2 text-sm">
                    {cartItems.map(item => (
                      <div key={item.slug} className="flex justify-between text-muted-foreground">
                        <span>{item.name} × {item.qty}</span>
                        <span>₹{item.price * item.qty}</span>
                      </div>
                    ))}
                  </div>
                  <div className="border-t border-dashed border-border pt-2 space-y-1.5 text-sm">
                    <div className="flex justify-between text-foreground">
                      <span>Subtotal</span><span>₹{cartSubtotal}</span>
                    </div>
                    <div className="flex justify-between text-foreground">
                      <span>Shipping</span>
                      <span className={cartShipping === 0 ? 'text-green-600 font-medium' : ''}>
                        {cartShipping === 0 ? 'FREE' : `₹${cartShipping}`}
                      </span>
                    </div>
                    {cartShipping > 0 && (
                      <p className="text-xs text-muted-foreground">Add ₹{SHIPPING_THRESHOLD - cartSubtotal} more for free delivery</p>
                    )}
                    <div className="flex justify-between font-bold text-lg text-foreground border-t border-border pt-2 mt-1">
                      <span>Total</span><span className="text-primary">₹{cartTotal}</span>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 pt-1">
                    <Button
                      className="w-full rounded-full bg-primary text-primary-foreground hover:bg-primary/90 py-6 font-semibold"
                      onClick={() => { setCartOpen(false); scrollToSection('order'); form.setValue('productSlug', cartItems[0].slug); form.setValue('quantity', cartItems[0].qty); }}
                    >
                      Proceed to Order Form
                    </Button>
                    <a
                      href={buildWhatsAppCartMessage()}
                      target="_blank" rel="noopener noreferrer"
                      className="w-full flex items-center justify-center gap-2 rounded-full bg-[#25D366] text-white py-3 font-semibold hover:bg-[#1ebe5d] transition-colors text-sm"
                    >
                      <MessageCircle className="w-4 h-4" /> Order via WhatsApp
                    </a>
                  </div>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Floating Cart Button */}
      <button
        onClick={() => setCartOpen(true)}
        data-testid="button-float-cart"
        className="fixed bottom-[5.5rem] right-6 z-50 w-14 h-14 rounded-full bg-primary text-primary-foreground shadow-2xl flex items-center justify-center hover:bg-primary/90 transition-all hover:scale-110"
        aria-label="View cart"
      >
        <ShoppingBag className="w-6 h-6" />
        {cartCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-secondary text-secondary-foreground text-[0.6rem] font-bold w-5 h-5 flex items-center justify-center rounded-full shadow">
            {cartCount}
          </span>
        )}
      </button>

      {/* Floating WhatsApp Button */}
      <a
        href="https://wa.me/919620965688?text=Hi!%20I%20visited%20your%20website%20and%20I%20want%20to%20order%20Sitara%20Soap%20%E2%9C%A8"
        target="_blank"
        rel="noopener noreferrer"
        data-testid="button-whatsapp-float"
        className="fixed bottom-6 right-6 z-50 flex items-center gap-2 bg-[#25D366] text-white px-5 py-3 rounded-full shadow-2xl hover:bg-[#1ebe5d] transition-all hover:scale-105 font-semibold text-sm"
      >
        <MessageCircle className="w-5 h-5" />
        Order via WhatsApp
      </a>

    </div>
  );
}
